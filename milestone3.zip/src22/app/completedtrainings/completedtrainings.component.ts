import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completedtrainings',
  templateUrl: './completedtrainings.component.html',
  styleUrls: ['./completedtrainings.component.css']
})
export class CompletedtrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
