import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentordash',
  templateUrl: './mentordash.component.html',
  styleUrls: ['./mentordash.component.css']
})
export class MentordashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
