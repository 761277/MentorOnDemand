import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HomenavComponent } from './homenav/homenav.component';
import { HomedashboardComponent } from './homedashboard/homedashboard.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { UserdashComponent } from './userdash/userdash.component';
import { UsernavComponent } from './usernav/usernav.component';
import { ProposedtrainingsComponent } from './proposedtrainings/proposedtrainings.component';
import { CompletedtrainingsComponent } from './completedtrainings/completedtrainings.component';
import { MentorhomeComponent } from './mentorhome/mentorhome.component';
import { MentornavComponent } from './mentornav/mentornav.component';
import { MentordashComponent } from './mentordash/mentordash.component';
import { PaymentsComponent } from './payments/payments.component';
import { NotificationsComponent } from './notifications/notifications.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HomenavComponent,
    HomedashboardComponent,
    SignupComponent,
    SigninComponent,
    UserhomeComponent,
    UserdashComponent,
    UsernavComponent,
    ProposedtrainingsComponent,
    CompletedtrainingsComponent,
    MentorhomeComponent,
    MentornavComponent,
    MentordashComponent,
    PaymentsComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
