import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proposedtrainings',
  templateUrl: './proposedtrainings.component.html',
  styleUrls: ['./proposedtrainings.component.css']
})
export class ProposedtrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
