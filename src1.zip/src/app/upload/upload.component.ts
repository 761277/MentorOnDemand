import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

  constructor() { }

  upload=true;
  getUpload(){
  return this.upload;
  }
  singleUpload(){
    this.upload=true;
  }
  multiUpload(){
    this.upload=!true;
  }
  ngOnInit() {
  }

}
