import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { UploadComponent } from './upload/upload.component';
import { MymediaComponent } from './mymedia/mymedia.component';
import { FollowersComponent } from './followers/followers.component';
import { AccountComponent } from './account/account.component';
import { NewsfeedComponent } from './newsfeed/newsfeed.component';
import { BlockedComponent } from './blocked/blocked.component';
import { UpdateComponent } from './update/update.component';
import { SearchaComponent } from './searcha/searcha.component';
//import { HomeComponent } from './home/home.component';


const routes: Routes = [
  {path: '', pathMatch: 'full', redirectTo: 'login'},
  {path:'login', component : LoginComponent},
  {path:'register', component : RegisterComponent},
  {path:'home', component : HomeComponent,
  children:[
    {path: '', pathMatch: 'full', redirectTo: 'upload'},
    {path:'upload', component:UploadComponent},
    {path:'mymedia', component:MymediaComponent},
    {path:'followers', component:FollowersComponent},
    {path:'account', component:AccountComponent,children:[
      {path: '', pathMatch: 'full', redirectTo: 'newsfeed'},
      {path:'newsfeed',component:NewsfeedComponent},
      {path:'blocked',component:BlockedComponent},
      {path:'update',component:UpdateComponent},
      {path:'search',component:SearchaComponent},

    ]
  },
  ]  
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
