import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searcha',
  templateUrl: './searcha.component.html',
  styleUrls: ['./searcha.component.css']
})
export class SearchaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
