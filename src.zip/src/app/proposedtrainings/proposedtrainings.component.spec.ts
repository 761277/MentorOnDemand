import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposedtrainingsComponent } from './proposedtrainings.component';

describe('ProposedtrainingsComponent', () => {
  let component: ProposedtrainingsComponent;
  let fixture: ComponentFixture<ProposedtrainingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposedtrainingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposedtrainingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
