import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { HomedashboardComponent } from './homedashboard/homedashboard.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { UserdashComponent } from './userdash/userdash.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { ProposedtrainingsComponent } from './proposedtrainings/proposedtrainings.component';


const routes: Routes = [
  {
    path:'',redirectTo:'home',pathMatch:'full'
  },
  {
    path:'home',component:HomeComponent,
    children:[
      {
        path:'',redirectTo:'homedashboard',pathMatch:'full'
      },
      {
        path:'homedashboard',component:HomedashboardComponent
      },
      {
        path:'signup',component:SignupComponent
      },
      {
        path:'signin',component:SigninComponent
      }
    ]
  },
  {
    path:'userhome',component:UserhomeComponent,
    children:[
      {
        path:'',redirectTo:'userdash',pathMatch:'full'
      },
      {
        path:'userdash',component:UserdashComponent
      },
      {
        path:'proposedtrainings',component:ProposedtrainingsComponent
      }
     
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
